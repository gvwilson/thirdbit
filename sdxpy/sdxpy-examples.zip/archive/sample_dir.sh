tree --charset ascii sample_dir
