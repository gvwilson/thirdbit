python hash_all.py sample_dir
