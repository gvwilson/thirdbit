# [def]
def example():
    print("in example")
# [/def]

# [alias]
alias = example
alias()
# [/alias]
