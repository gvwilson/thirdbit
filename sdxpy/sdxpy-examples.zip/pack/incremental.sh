python incremental.py < triple.json
