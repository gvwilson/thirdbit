python incremental.py reversed < triple.json
