from z3 import Bool, Implies, Not, Solver, sat, unsat

A = Bool("A")
B = Bool("B")
C = Bool("C")
