python exhaustive.py < triple.json
