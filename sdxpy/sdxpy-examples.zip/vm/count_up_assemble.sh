python assembler.py count_up.as -

