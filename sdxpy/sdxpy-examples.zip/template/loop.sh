python template.py vars.json loop.ht
