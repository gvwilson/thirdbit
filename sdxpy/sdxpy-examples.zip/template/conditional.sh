python template.py vars.json conditional.ht
