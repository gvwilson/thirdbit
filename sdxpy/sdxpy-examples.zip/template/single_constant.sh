python template.py vars.json single_constant.ht
