def example():
    pass

print(type(example))
