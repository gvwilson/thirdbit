def example():
    pass

print(callable(example), callable(len))
