import pprint
pprint.pprint(globals())
