import pprint
my_variable = 123
pprint.pprint(globals())
