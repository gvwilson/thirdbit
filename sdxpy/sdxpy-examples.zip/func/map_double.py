def double(x):
    return 2 * x

data = [5, 10, 15]
print(list(map(double, data)))
