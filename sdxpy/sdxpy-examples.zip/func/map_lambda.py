data = [5, 10, 15]

# [keep]
print(list(map(lambda x: 2 * x, data)))
# [/keep]
