python func.py dynamic.tll
