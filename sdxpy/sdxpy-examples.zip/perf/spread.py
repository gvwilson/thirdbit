def example(left, right):
    print(left, right)

args = {"right": 3, "left": 5}
example(**args)
