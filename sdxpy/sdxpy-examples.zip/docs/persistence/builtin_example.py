import sys
from builtin import save

save(sys.stdout, [False, 3.14, "hello", {"left": 1, "right": [2, 3]}])
