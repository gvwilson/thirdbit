python manual.py < triple.json
