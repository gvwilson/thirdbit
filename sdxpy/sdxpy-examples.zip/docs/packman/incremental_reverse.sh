python incremental.py triple reversed
