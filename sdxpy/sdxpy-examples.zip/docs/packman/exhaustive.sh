python exhaustive.py triple
