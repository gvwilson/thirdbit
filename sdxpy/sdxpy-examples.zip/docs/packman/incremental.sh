python incremental.py triple
