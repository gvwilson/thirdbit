python try_glob.py sample_dir
