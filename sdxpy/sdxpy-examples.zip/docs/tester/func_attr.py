def example():
    "Docstring for example."
    print("in example")

# [print]
print("docstring:", example.__doc__)
print("name:", example.__name__)
# [/print]
