def show_off(some_parameter):
    some_variable = some_parameter * 2
    print("local values", locals())

show_off("hello")
