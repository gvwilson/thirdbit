def example():
    print("in example")

# [replacement]
def replacement():
    print("in replacement")

example = replacement
example()
# [/replacement]
