# [define_example]
def example():
    print("in example")
# [/define_example]

# [alias]
alias = example
alias()
# [/alias]
