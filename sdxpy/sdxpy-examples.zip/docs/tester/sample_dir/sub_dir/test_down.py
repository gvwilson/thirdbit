def test_error():
    assert 1/0
