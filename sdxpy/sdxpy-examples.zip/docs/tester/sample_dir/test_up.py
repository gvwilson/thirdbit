title = "testing example"

def test_succeeds():
    assert True

def test_fails():
    assert False
