python template.py vars.json multiple_variables.ht
