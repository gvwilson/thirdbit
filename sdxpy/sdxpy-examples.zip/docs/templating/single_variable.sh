python template.py vars.json single_variable.ht
