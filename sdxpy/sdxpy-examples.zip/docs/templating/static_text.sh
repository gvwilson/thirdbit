python template.py vars.json static_text.ht
