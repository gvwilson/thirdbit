python vm.py count_up.mx -

