python vm.py fill_array.mx -

