python assembler.py halt.as -
