python assembler.py print_r1.as -
