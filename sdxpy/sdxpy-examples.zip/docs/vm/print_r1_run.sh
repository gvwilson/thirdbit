python vm.py print_r1.mx -

