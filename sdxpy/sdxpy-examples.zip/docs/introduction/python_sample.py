for thing in collection:
    print(thing)
