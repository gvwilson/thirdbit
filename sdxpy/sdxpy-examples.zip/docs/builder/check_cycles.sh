python graph_creator.py circular_rules.yml
