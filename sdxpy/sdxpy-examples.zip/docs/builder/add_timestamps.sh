python add_timestamps.py three_simple_rules.yml add_timestamps.yml
