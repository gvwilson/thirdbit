python graph_creator.py three_simple_rules.yml
