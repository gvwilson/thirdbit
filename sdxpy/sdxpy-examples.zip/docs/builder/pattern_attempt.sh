python pattern_attempt.py pattern_rules.yml pattern_times.yml
