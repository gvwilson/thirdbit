def add(left, right):
    return left + right

def double(x):
    return add(x, x)

add(1, 2)
double(3)
