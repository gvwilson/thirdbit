def double(x):
    result = 2 * x
    return result


value = 3
result = double(value)
print(result)
