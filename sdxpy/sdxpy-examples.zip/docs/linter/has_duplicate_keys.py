no_duplicates = {"first": 1, "second": 2}

has_duplicates = {"third": 3, "fourth": 4, "fourth": 5, "third": 6}
