COLUMNS=72 pytest test_tokenizer.py
