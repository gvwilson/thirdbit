echo "ABCQ" | python log_keystrokes.py log_keystrokes.out
