python -m cProfile -s tottime timing.py 1000x1000 | head -n 20
