python hash_stream.py frankenstein.txt
