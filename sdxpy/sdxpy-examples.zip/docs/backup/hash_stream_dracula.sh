python hash_stream.py dracula.txt
