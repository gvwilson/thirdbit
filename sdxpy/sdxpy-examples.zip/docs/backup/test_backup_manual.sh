python backup.py sample_dir /tmp/backups
tree --charset ascii /tmp/backups
