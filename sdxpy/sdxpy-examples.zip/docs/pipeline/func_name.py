def proof(x, y):
    pass

print(proof.__name__)
