COLUMNS=72 pytest test_placed.py
