COLUMNS=72 pytest test_easy_mode.py
