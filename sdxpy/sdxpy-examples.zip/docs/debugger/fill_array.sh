python assembler.py fill_array.as - | python vm_base.py - -
