python func.py func.tll
