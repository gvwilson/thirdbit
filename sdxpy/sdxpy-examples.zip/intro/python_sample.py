for ch in "example":
    print(ch)
