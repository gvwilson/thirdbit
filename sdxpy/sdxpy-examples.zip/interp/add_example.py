["add", 1, 2]            # add 1 and 2
["abs", -3.5]            # get the absolute value of 3.5
["add", ["abs", -5], 9]  # combine
