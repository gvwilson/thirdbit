python stmt.py repeat_zero.tll
