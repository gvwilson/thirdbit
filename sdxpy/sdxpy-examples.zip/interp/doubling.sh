python stmt.py doubling.tll
