python basic_http_server.py
