python brute_force_1.py tests/*.txt
