python dup.py tests/*.txt
