text = "hello"
print(f"{len(text)}s")
