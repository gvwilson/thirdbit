from variable_packing import pack_string
# [main]
result = pack_string("こんにちは!")
print(repr(result))
# [/main]
