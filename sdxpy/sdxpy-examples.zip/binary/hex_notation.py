print(0x2D)  # (2 * 16) + 13
