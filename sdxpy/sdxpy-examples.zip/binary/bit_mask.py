mask = ~0x0100    # binary 1111 1110 1111 1111
val = val & mask  #    clears this ^ bit
