shared = ["shared"]
fixture = [shared, shared]
