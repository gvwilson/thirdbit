def example():
    "Docstring for example."
    print("in example")

print(dir(example))
