if x != 0:
    return 1/x
else:
    return None
