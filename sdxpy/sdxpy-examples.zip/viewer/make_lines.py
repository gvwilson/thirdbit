from util import make_lines

for line in make_lines(5):
    print(line)
