python dump_ast.py simple.py
