def double(x):
    return 2 * x

result = double(3)
print(result)
