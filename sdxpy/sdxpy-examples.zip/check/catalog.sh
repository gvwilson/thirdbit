python catalog.py page.html
