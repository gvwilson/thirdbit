python check.py manifest.yml page.html
