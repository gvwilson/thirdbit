python walk_ast.py simple.py
