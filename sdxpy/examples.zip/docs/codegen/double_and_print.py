def double(x):
    return 2 * x

print(double(3))
