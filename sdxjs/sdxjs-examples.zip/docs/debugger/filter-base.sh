node run-base.js filter-base.json
