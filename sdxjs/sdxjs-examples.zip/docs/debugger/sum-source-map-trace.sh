node run-callback.js sum-source-map.json
