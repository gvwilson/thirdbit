node run-source-map.js filter-source-map.json
