class HaltException {
}

export default HaltException
