node pray.js -v
