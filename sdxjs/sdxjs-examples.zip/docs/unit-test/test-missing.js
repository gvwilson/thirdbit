import assert from 'assert'
import hope from './hope.js'

hope.test('Sum of x and 0', () => assert((x + 0) === x)) // eslint-disable-line
