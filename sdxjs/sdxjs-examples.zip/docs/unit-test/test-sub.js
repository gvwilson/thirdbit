import assert from 'assert'
import hope from './hope.js'

hope.test('Difference of 1 and 2', () => assert((1 - 2) === -1))
