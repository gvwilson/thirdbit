Promise.resolve('hello')
