const p = new Promise((resolve, reject) => resolve('hello'))
  .then(result => console.log(result))
