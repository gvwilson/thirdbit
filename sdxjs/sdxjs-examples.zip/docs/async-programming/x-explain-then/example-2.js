Promise.resolve('hello').then(result => console.log(result))
