node count-lines-with-stat-async.js .
