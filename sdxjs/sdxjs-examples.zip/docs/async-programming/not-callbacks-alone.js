[1000, 1500, 500].forEach(t => console.log(t))
