node await-fs.js short-quote.out
