node return-immediately.js 2>&1 | head -n 1
