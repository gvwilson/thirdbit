node count-lines-globbed-files.js .
