node count-lines-single-file.js count-lines-single-file.js
