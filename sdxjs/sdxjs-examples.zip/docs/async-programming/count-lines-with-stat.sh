node count-lines-with-stat.js .
