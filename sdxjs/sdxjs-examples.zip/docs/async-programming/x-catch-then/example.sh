node example.js 2>&1 | ../../_tools/wrap.js >& example.txt
