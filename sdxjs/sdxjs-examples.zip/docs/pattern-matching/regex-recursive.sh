cd regex-recursive
node regex-complete.js
