cd regex-beginning
node regex-complete.js
