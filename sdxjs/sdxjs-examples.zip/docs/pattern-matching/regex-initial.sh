cd regex-initial
node regex-complete.js
