for (const thing in collection) {
  console.log(thing)
}
