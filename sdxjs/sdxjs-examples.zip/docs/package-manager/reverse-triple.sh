node driver.js ./reverse.js triple.json
