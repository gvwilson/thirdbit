node driver.js ./sweep.js triple.json
