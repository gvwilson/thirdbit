node driver.js ./sweep.js double-chained.json
