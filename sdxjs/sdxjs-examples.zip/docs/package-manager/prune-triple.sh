node driver.js ./prune.js triple.json
