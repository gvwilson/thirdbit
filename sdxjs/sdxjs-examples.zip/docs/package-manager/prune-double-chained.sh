node driver.js ./prune.js double-chained.json
