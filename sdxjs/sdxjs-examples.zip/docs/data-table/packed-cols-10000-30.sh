node packed-cols.js 10000 30
