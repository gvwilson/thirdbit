node table-performance.js 10000 30 3
