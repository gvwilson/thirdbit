node table-performance.js 100 3 3
