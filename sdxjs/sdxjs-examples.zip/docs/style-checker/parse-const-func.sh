node parse-const-func.js | head -n 30
echo "...$(expr $(node parse-const-func.js | wc -l) - 30) more lines..."
