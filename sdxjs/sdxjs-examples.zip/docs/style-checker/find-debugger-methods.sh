node run-find-methods.js ../debugger debugger-exit.js DebuggerExit
