node sniff.js my-check.js source-1.js source-2.js
