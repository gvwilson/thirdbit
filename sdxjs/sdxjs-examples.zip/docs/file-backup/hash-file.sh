node hash-file.js hash-file.js
