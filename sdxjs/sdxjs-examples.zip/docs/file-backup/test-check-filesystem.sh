npm run test -- -g 'pre-existing hashes'
