node run-hash-existing-async.js . | fgrep -v test/ | fgrep -v '~'
