node hash-text.js something
