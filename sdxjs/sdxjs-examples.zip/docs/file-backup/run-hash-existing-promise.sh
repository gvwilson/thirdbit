node run-hash-existing-promise.js . | fgrep -v test/ | fgrep -v '~'
