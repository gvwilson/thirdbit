npm run test -- -g 'easy mode'

