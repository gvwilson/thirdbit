// eslint-disable
const initialize = (creators) => {

// /u/stjs/stjs/module-bundler/single/main.js
creators.set('/u/stjs/stjs/module-bundler/single/main.js',
(module, require) => {const main = () => {
  console.log('in main')
}

module.exports = main
})


}

