node bundle-simple.js > test-bundle-simple.out
