const main = () => {
  console.log('in main')
}

module.exports = main
