const main = require('./main')
main()
