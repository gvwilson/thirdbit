// subdir/bottom-right.js

const bottomRight = (caller) => {
  return `bottomRight from ${caller}`
}

module.exports = bottomRight
