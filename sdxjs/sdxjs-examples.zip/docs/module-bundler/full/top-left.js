// top-left.js

const topLeft = (caller) => {
  return `topLeft from ${caller}`
}

module.exports = topLeft
