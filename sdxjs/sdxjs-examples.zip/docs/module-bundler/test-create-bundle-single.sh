echo '// eslint-disable' > bundle-single.js
node test-create-bundle.js single/main.js >> bundle-single.js
