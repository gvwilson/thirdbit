import getRequires from './get-requires.js'

const result = getRequires(process.argv[2])
console.log(result)
