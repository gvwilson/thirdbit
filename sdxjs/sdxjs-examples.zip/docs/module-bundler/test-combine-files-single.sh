echo '// eslint-disable' > test-combine-files-single.js
node test-combine-files.js single/main.js >> test-combine-files-single.js
