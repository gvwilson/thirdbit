cd single
node run.js
