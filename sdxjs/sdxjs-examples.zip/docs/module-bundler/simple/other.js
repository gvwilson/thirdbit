const other = (caller) => {
  return `other called from ${caller}`
}

module.exports = other
