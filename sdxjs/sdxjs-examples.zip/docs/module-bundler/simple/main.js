const other = require('./other')

const main = () => {
  console.log(other('main'))
}

module.exports = main
