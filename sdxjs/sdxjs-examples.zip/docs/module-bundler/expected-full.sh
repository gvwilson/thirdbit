cd full
node run.js
