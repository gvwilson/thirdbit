node test-transitive-closure.js full/main.js
