echo '// eslint-disable' > bundle-simple.js
node test-create-bundle.js simple/main.js >> bundle-simple.js
