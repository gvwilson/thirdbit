node bundle-single.js > test-bundle-single.out
