import createBundle from './create-bundle.js'

console.log(createBundle(process.argv[2]))
