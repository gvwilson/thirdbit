node test-get-requires.js simple/main.js
