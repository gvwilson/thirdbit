cat test-combine-files-simple.js console-everything.js | node
