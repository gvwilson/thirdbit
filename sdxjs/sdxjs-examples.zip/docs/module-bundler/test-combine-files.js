import combineFiles from './combine-files.js'

console.log(combineFiles(process.argv.slice(2)))
