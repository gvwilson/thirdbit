const creators = new Map()
initialize(creators) // eslint-disable-line
console.log(creators)
