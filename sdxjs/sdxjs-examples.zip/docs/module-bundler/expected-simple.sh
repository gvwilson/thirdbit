cd simple
node run.js
