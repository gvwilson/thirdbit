node test-transitive-closure-only.js full/main.js
