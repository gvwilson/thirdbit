node as.js ./assembler.js print-r1.as print-r1.mx
