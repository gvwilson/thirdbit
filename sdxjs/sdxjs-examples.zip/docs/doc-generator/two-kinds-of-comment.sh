node extract-comments.js two-kinds-of-comment.js
