node extract-comments-subset.js multi-line-double-slash-comment.js
