node extract-comments-subset.js two-kinds-of-comment.js
