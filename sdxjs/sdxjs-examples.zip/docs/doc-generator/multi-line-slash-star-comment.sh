node extract-comments-subset.js multi-line-slash-star-comment.js
