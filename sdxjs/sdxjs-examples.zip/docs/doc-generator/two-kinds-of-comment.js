// double-slash comment
/* slash-star comment */
