node template.js vars.json input-single-variable.html
