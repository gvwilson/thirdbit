node template.js vars.json input-single-constant.html
