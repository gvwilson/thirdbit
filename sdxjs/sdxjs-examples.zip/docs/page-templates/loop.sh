node template.js vars.json input-loop.html
