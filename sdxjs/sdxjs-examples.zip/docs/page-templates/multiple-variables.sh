node template.js vars.json input-multiple-variables.html
