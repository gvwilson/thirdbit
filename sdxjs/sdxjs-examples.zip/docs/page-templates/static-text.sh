node template.js vars.json input-static-text.html
