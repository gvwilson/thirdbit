import need from './need.js'

const large = need('large-module.js')
console.log(large.large('main'))
