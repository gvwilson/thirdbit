node test-need-large-module.js
