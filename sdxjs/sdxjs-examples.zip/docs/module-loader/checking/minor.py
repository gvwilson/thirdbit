# minor.py

import major

def middle():
    print("middle")
    major.bottom()
