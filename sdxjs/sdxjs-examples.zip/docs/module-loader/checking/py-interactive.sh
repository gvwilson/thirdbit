echo '$ python'
echo '>>> import major'
echo 'import major' | python
