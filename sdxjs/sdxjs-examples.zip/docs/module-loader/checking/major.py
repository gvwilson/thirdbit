# major.py

import minor

def top():
    print("top")
    minor.middle()

def bottom():
    print("bottom")

top()
