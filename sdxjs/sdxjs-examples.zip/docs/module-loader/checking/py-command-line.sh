python major.py
