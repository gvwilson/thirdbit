node major.js
