node test-load-module-only.js small-module.js
