import need from './need.js'

const large = need('large-needless.js')
console.log(large('main'))
