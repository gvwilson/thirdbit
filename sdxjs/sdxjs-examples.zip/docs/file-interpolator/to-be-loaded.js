// eslint-disable
// Modify a global structure defined by whoever loads us.
Seen.from_loaded_file = 'from loaded file'
