node test-import-interpolate.js
