import need from './need-path.js'
const imported = need('imported-left.js')
imported('called from test-import-left.js')
