import need from './need-simple.js'

const imported = need('./import-simple.js')
imported('called from test-simple.js')
