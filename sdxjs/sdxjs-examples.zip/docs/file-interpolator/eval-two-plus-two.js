// eslint-disable no-eval
console.log(eval('2 + 2'))
