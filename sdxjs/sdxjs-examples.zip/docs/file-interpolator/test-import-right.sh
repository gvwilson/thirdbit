NEED_PATH=$PWD/modules/ node test-import-right.js
