// eslint-disable
// Define.
const report = (message) => {
  console.log(`in LEFT with message "${message}"`)
}

// Export.
report
