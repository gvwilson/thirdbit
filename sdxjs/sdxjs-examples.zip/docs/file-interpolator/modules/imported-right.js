// eslint-disable
// Define.
const report = (message) => {
  console.log(`in RIGHT with message "${message}"`)
}

// Export.
report
