// eslint-disable
bottomMethod (msg) {
  console.log(`(bottomMethod ${msg})`)
}
