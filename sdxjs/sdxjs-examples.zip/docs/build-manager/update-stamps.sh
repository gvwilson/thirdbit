node driver.js ./update-stamps.js three-simple-rules.yml add-stamps.yml
