node driver.js ./variable-expander.js three-variable-rules.yml add-stamps.yml
