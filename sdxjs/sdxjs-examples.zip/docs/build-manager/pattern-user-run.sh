node driver.js ./pattern-user-run.js pattern-rules.yml
