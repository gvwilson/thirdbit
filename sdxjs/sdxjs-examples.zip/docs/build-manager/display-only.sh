node driver.js ./display-only.js three-simple-rules.yml
