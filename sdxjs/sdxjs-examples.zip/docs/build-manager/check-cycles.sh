node driver.js ./display-only.js circular-rules.yml
