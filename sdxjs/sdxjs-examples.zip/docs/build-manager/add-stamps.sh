node driver.js ./add-stamps.js three-simple-rules.yml add-stamps.yml
