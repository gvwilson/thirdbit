node driver.js ./pattern-user-show.js pattern-rules.yml
