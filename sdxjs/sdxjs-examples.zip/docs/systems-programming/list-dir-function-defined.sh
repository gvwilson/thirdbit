node list-dir-function-defined.js .
