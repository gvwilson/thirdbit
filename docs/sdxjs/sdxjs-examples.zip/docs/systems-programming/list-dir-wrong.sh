node list-dir-wrong.js .
