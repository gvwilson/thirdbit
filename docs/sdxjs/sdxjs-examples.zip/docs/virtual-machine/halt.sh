node as.js ./assembler.js halt.as halt.mx
