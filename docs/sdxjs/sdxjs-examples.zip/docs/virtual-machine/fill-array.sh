node as.js ./allocate-data.js fill-array.as fill-array.mx
