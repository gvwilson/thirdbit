node as.js ./assembler.js count-up.as count-up.mx
