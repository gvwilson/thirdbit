node run-find-ancestors.js . lower.js Lower
