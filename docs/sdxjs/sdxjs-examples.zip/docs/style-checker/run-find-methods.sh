node run-find-methods.js . lower.js Lower
