node storage-performance.js 10000 30
