node packed-rows.js 10000 30
