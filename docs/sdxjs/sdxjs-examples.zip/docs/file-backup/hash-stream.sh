node hash-stream.js hash-stream.js
