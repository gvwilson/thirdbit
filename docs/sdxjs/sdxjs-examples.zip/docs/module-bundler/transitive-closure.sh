node transitive-closure.js full/main.js
