echo '// eslint-disable' > bundle-full.js
node test-create-bundle.js full/main.js >> bundle-full.js
