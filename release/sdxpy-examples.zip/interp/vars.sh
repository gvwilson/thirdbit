python vars.py vars.tll
