python grouped.py tests/*.txt
